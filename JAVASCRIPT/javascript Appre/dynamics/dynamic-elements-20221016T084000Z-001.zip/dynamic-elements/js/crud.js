
function gotoPage(pagename,msg){

    if(pagename == 'login'){

        window.location.href = getBaseurl(pagename + '.html');
        return; //code execute stop.
       
    }else if(pagename == 'logout'){

        let status = window.confirm(msg); //ok cancel
        if(status){

            window.localStorage.removeItem('session');
            window.location.href = getBaseurl('login.html#log-out'); //Jis page chahtey logout honey
            //bad jaye 
        }

    }else{
        window.location.href = getBaseurl(pagename + '.html');
        return; //code execute stop.
    }
  
}


//registerUser
function registerUser(e){

    e.preventDefault(); //default behaviour to Stop Kardo.
    let name = $("#name"); //document.getElementById('name');
    //console.log(name.value);
    let email = $("#email"); //document.getElementById('email');
    //console.log(email.value);
    let password = $("#password"); //document.getElementById('password');
    //console.log(password.value);
    let mobile = $("#mobile"); //document.getElementById('mobile');
    //console.log(mobile.value);  


    var collections = JSON.parse(window.localStorage.getItem('user_data')) || [];
   // console.log(collections);

    let users = {
        name:name.value,
        email:email.value,
        password:password.value,
        mobile:mobile.value,
    }

    //JSON.stringify() : JsonObject => JSONString
    //JSON.parse() : JsonString => JsonObject

    //Object and Array of Object.

    collections.push(users);
    window.localStorage.setItem('user_data',JSON.stringify(collections));
    success_alert("Registration Successfull");

}


function contactUser(e){
    
    e.preventDefault(); //default behaviour to Stop Kardo.
    let name = $("#name");
    //console.log(name.value);
    let email = $("#email");
    //console.log(email.value);
    let message = $("#message");
    //console.log(message.value);
    let mobile = $("#mobile");
    //console.log(mobile.value);
    var collections = JSON.parse(window.localStorage.getItem('contact_data')) || [];
    console.log(collections);

    let users = {
        name:name.value,
        email:email.value,
        message:message.value,
        mobile:mobile.value,
    }
    collections.push(users);
    window.localStorage.setItem('contact_data',JSON.stringify(collections));
    success_alert("Thank you for Contacting,Your Enquiry Send Successfully");

}

function loginUser(e){

    e.preventDefault();
    let email  = $("#email");
    let password = $("#password");
    
    let userCollection_str = window.localStorage.getItem('user_data');
    let userCollection_obj = JSON.parse(userCollection_str);
    
    let user_data = findRecord(email,password,userCollection_obj);
    if(user_data){      

        let session = {
            data:user_data,
            is_login:true,
        }
        window.localStorage.setItem('session',JSON.stringify(session));
        window.location.href = getBaseurl('dashboard.html#login-success');

    }else{
        error_alert('Invalid User Name or Password');
    }

}









