//Example of let,var, const
//variable and constant
// variable : jiski value bar bar change ki ja sakti hai
//const  : Ek bar jo value assign fir badal nhi sakti
// eg : g => gravity => 9.8 => 9.4 X
// eg : pi => 3.14 => constant => X
//re-declaration
//re-initialise

console.clear();
const g=9.8;  //constant
console.log(g); //9.8
console.log(typeof g); //Number
g=10; //g => varaible X => constant 
console.log(g); 

//const g =10; //let x=10 invalid var x=10 var x=20; valid
var y=100; //re-declare
var y=200; //re-declare
var y=300; //re-declare 
console.log(y);
let z1=10;
console.log('z1 value = ', z1);
z1 = 20;
console.log('z1 value = ', z1);











