<?php

//wap in php to show, Sapi Mode in php

echo php_sapi_name();