<?php

print_r($argv);
echo PHP_EOL;

echo $argc;
echo PHP_EOL;

echo getType($argv);
echo PHP_EOL;

?>