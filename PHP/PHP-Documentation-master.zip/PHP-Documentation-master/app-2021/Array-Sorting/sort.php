<?php

//wap in php to show sort and rsort

$a = [10,200,50,60,30,20,40,100];
sort($a);

print_r($a);
rsort($a);

print_r($a);