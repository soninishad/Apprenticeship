<?php

include 'b.phps';
include 'b.php';
include_once 'b.php';
include_once 'b.php';
require 'p1.phps';
require_once 'p1.php';

echo 'Message from a.php';
echo PHP_EOL;

