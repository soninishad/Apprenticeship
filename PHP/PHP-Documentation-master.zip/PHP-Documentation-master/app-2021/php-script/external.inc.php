<?php
defined('APP_KEY') or exit('No Permission To Access this File Directly');

function wish(){
	echo 'Merry Christmas !!!!';
}

wish();