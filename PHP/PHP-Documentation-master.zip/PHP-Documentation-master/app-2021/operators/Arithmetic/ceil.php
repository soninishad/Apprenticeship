<?php

//wap in php to show the concept of ceil concept.

$no1 = readline('Enter any float value:');
echo "The floating point value = $no1 ";
echo PHP_EOL;

$no2 = ceil($no1);

echo "The ceil value = $no2 ";