<?php

//wap in php to show Assignment Operators

$sum = 10;
$x=20;


$sum = $sum+$x;
echo "The value of sum without Assignment : $sum \n";

$sum = 10;
$x=20;

$sum +=$x;
echo "The value of sum with Assignment : $sum \n";











