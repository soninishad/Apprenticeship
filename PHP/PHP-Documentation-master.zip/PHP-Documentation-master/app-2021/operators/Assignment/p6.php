<?php

//wap in php to show Dot(.) Assignment Operators or Concate Assignment Operator

$sum = 'Good';
$x=' Morning';


$sum = $sum . $x;
echo "The value of Result without Assignment : $sum \n";

$sum = 'Good';
$x=' Morning';

$sum .=$x;
echo "The value of Result with Assignment : $sum \n";











