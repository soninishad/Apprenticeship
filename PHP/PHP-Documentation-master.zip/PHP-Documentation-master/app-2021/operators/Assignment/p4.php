<?php

//wap in php to show / Assignment Operators

$sum = 5;
$x=2;


$sum = $sum/$x;
echo "The value of Result without Assignment : $sum \n";

$sum = 5;
$x=2;

$sum /=$x;
echo "The value of Result with Assignment : $sum \n";











