<?php

//wap in php to show logical Operators Not

$x=readline('Enter the x value in Range:');

var_dump($x!=10);  //Not Equal to
var_dump(!($x==10));  //Logical Not


