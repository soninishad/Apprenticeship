<?php


//wap in php to find +ve and -ve

$a=readline('Enter the a value:');
$output = ($a>0)?'+ve':'-ve';
echo $output;





