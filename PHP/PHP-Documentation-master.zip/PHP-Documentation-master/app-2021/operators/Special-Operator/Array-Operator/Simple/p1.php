<?php

//wap in php to + Operation in Array

$x=[10,20,30,'ravi'];

$y[4]='Doremon';
$y[5]=100;
$y[6]=200;

print_r($x);
print_r($y);
print_r($x + $y); //$x.add($y)

// subscript unique : Add
// subscript duplicate : Over-write
// latest value, will be stored.





