<?php


//wap in php to show, Object using Class

class Student{

private $name= 'Awnish';
private $class= 'Btech';
private $rollno= 1001;
private $wife= 'Katreena';
private $enemy= 'Vicky Kaushal';
private $friend= 'Salman';

}

$std=new Student();
var_dump($std); //user-defined ---> type Resource
