
<?php

//wap in php to assign the array to varible

$color[0]='red';
$color[1]='green';
$color[2]='orange';
$color[3]='black';

echo getType($color);
echo PHP_EOL;
print_r($color);

$colors[]='RED';
$colors[]='GREEN';
$colors[]='Orange';
$colors[]='Black';
$colors[]='WhIte';
echo PHP_EOL;
print_r($colors);


$arr = ['Red Label','Blenders Pride','8PM','8pm Black','Bunty and Bubbly','tuborg','Appie Fiz','Magic Moment','Black Dog','KingFisher','Desi','Royal Stack','Imperial Blue'];

print_r($arr);







