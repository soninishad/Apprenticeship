<?php


include 'scanner.php';

$name = input('Enter the name:');
echo $name;

echo PHP_EOL;

$class = input('Enter the class:');
echo $class;

?>