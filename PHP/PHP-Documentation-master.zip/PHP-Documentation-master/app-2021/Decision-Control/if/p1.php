<?php

//wap in php to show condition Block 

$n=readline('Enter n value:');
echo "first line ".__LINE__." is executing \n";
if($n==5){
	echo "another line ".__LINE__." is executing \n";
}
echo "another line ".__LINE__." is executing \n";
echo "last line ".__LINE__." is executing \n";
