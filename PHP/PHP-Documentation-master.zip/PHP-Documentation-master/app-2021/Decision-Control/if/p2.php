<?php

//wap in php to find odd and even

$n = readline('Enter the Number:');
if($n%2==0){
	echo 'no is even';
}
if($n%2==1){
	echo 'no is Odd';
}


