<?php


//wap in php to show Exception Over, Error 
//Note Exception Occurs when, Stack Trace #main(thrown) Exception.... : Fatal Error


class Test{

}

$test = new Test();
$test->doSomething();
