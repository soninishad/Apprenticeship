<?php

echo 'This is Working File';
$x=20;

?>

<h1>The value of x = <?php echo $x; ?></h1>
<h1>The value of x = <?=$x; ?></h1>