<?php

$conn = mysqli_connect('localhost','u541293459_gargipaperkraf','Narayan@1101');
mysqli_select_db($conn,"u541293459_gargipaperkraf");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

?>