<nav class="pcoded-navbar">
                        <div class="nav-list">
                            <div class="pcoded-inner-navbar main-menu">
                                <div class="pcoded-navigation-label">Navigation</div>
                                <ul class="pcoded-item pcoded-left-item">
                                    <li class="pcoded-hasmenu">
                                        <a href="admin" class="waves-effect waves-dark">
                                            <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                                            <span class="pcoded-mtext">Dashboard</span>
                                        </a>
                                    </li>

                                   
                                         
                                            <!--<a href="javascript:void(0)" class="waves-effect waves-dark">-->
                                            <!--    <span class="pcoded-micon">-->
                                            <!--        <i class="feather icon-box"></i>-->
                                            <!--    </span>-->
                                            <!--    <span class="pcoded-mtext">About</span>-->
                                            <!--</a>-->
                                            <!-- <ul class="pcoded-mtext pcoded-submenu">-->
                                            <!--    <li class="pcoded-hasmenu">-->
                                            <!--        <a href="all_about" class="waves-effect waves-dark">-->
                                            <!--            <span class="pcoded-micon">-->
                                            <!--             <i class="feather icon-box"></i>-->
                                            <!--            </span>-->
                                            <!--            <span class="pcoded-mtext">About Us</span>-->
                                            <!--        </a>-->
                                            <!--   <ul class="pcoded-mtext pcoded-submenu">-->
                                            <!--    <li class="pcoded-hasmenu">-->
                                            <!--        <a href="add_about" class="waves-effect waves-dark">-->
                                            <!--            <span class="pcoded-micon">-->
                                            <!--             <i class="feather icon-box"></i>-->
                                            <!--            </span>-->
                                            <!--            <span class="pcoded-mtext">Add About</span>-->
                                            <!--        </a>-->
                                            <!--  </li>-->
                                            <!--  <li class="pcoded-hasmenu">-->
                                            <!--        <a href="all_about" class="waves-effect waves-dark">-->
                                            <!--            <span class="pcoded-micon">-->
                                            <!--             <i class="feather icon-box"></i>-->
                                            <!--            </span>-->
                                            <!--            <span class="pcoded-mtext">All About</span>-->
                                            <!--        </a>-->
                                            <!--  </li>-->
                                            <!--</ul>-->
                                            <!--</ul>-->

                                         <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">PaperKraft Products</span>
                                            </a>                                             
                                            <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Products Category</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_paperkraft_products" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add PaperKraft Products</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_paperkraft_products" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Show PaperKraft Products</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                          
                                             <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Team Member</span>
                                            </a>                                             
                                            <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Our Team</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_team" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Team</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_team" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Team</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                            

                                             <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Flat Bottom Bags</span>
                                            </a>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Flat Bottom Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_flat_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Flat Bottom Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_flat_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Flat Bottom Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>

                                        <!--     <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Laundry Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_laundry_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Laundry Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_laundry_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Laundry Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->

                                          <!--   <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Medical Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_medical_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Medical Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_medical_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Medical Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->

                                          



                                            <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">V Bottom Bags</span>
                                            </a>

                                            <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">V Bottom Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_v_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add V Bottom Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_v_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All V Bottom Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                           <!--   <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Grocery Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_grocery_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Grocery Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_grocery_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Grocery Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
 -->
                                         <!--    <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Sweets Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_sweets_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Sweets Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_sweets_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Sweets Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->

                                          <!--    <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Namkeen Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_namkeen_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Namkeen Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_namkeen_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Namkeen Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->

                                          <!--   <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Fast Food Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_fast_food_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Fast Food Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_fast_food_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Fast Food Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->
                                               <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Square Bottom Bags</span>
                                            </a>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Square Bottom Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_square_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Square Bottom Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_square_bottom_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Square Bottom Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                            <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Bags Portfolio</span>
                                            </a>
                                             

                                          <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Flat Bottom Portfolio</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_flat_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Portfolio Design</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_flat_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Portfolio Designs</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>

                                          <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">V Bottom Portfolio</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_v_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Portfolio Design</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_v_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Portfolio Designs</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> 


                                    <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Square Bottom Portfolio</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_square_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Portfolio Design</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_square_bottom_design" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Portfolio Designs</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> 

                                             <!--  <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Vegetable Bags</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_vegtable_bag" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Vegetable Bag</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_vegetable_bags" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Vegetable Bags</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul> -->
                                           
                                           

                                            

                                              <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Clients</span>
                                            </a>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Clients</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_clients" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Clients</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_clients" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Clients</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                               <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Media</span>
                                            </a>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Media</span>
                                                    </a>
                                              <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="add_media" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Add Media</span>
                                                    </a>
                                              </li>
                                              <li class="pcoded-hasmenu">
                                                    <a href="all_media" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">All Media</span>
                                                    </a>
                                              </li>
                                            </ul>
                                            </ul>
                                           <li class="pcoded-hasmenu">
                                            <a href="https://sso.godaddy.com/?app=email&realm=pass"  target="_blank" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Godaddy E-mail Login</span>
                                            </a>
                              
                                        
                                          <li class="pcoded-hasmenu">
                                            <a href="javascript:void(0)" class="waves-effect waves-dark">
                                                <span class="pcoded-micon">
                                                    <i class="feather icon-box"></i>
                                                </span>
                                                <span class="pcoded-mtext">Setting</span>
                                            </a>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="all_header" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Front-Header</span>
                                                    </a>
                                        
                                            </ul>
                                            <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="all_logo" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Company Logo</span>
                                                    </a>
                                          
                                            </ul>
                                             <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="all_flutter" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Front-Footer</span>
                                                    </a>
                                             
                                            </ul>

                                            <ul class="pcoded-mtext pcoded-submenu">
                                                <li class="pcoded-hasmenu">
                                                    <a href="all_login_background" class="waves-effect waves-dark">
                                                        <span class="pcoded-micon">
                                                         <i class="feather icon-box"></i>
                                                        </span>
                                                        <span class="pcoded-mtext">Login_Background Cover</span>
                                                    </a>
                                                </li>
                                            </ul>
                                    </div>
                                </div>
                            </nav>
