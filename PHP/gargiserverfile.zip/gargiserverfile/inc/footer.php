   <footer class="site-footer footer-light">
            <!-- COLL-TO ACTION START -->
            <div class="section-full overlay-wraper site-bg-primary" style="background-image:url(images/background/bg-7.png);">
            	
                <div class="section-content ">
                <!-- COLL-TO ACTION START -->
                	<div class="wt-subscribe-box">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8 col-sm-8">
                                    <div class="call-to-action-left p-tb20 p-r50">
                                        <h4 class="text-uppercase m-b10">We are ready to manufacture your paperkraft bags as per your reuqired in bulk quantity</h4>
                                      
                                    </div>
                                </div>
                                
                                <div class="col-md-3">
                                    <div class="call-to-action-right p-tb30">
                                        <a href="enquiry" class="site-button-secondry text-uppercase radius-sm font-weight-600">
                                            Enquiry Now
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            
                                
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div class="col-lg-4 col-md-12" >  
                            <div class="widget widget_about">
                                <h4 class="widget-title" style="color: #1e86a1;">About Gargi Paperkraft</h4>                              
                                <p>Since its inception five years ago, Gargi PaperKraft was laid on foundation of Enterprise, Integrity and Innovation. Gargi PaperKraft is a premier manufacturer & supplier of different kind of Paper Bags.  </p>  
                            </div>
                        </div> 
                     
                        <!-- USEFUL LINKS -->
                        <div class="col-lg-4 col-md-12 " >
                            <div class="widget widget_services">
                                <h4 class="widget-title" style="color: #1e86a1;">Useful links</h4>
                                <ul>
                                    <li><a href="about-gargi-paperkraft">About Us</a></li>
                                    <li><a href="gargi-paperkraft-products">Products</a></li>
                                     <li><a href="gargi-paperkraft-media">Media</a></li>
                                    <li><a href="enquiry">Contact</a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 " >
                            <div class="widget widget_services">
                                <h4 class="widget-title" style="color: #1e86a1;">Paperkraft Bags Portfolio </h4>
                                <ul>
                                    <li><a href="flat-bottom">Flat-Bottom Bags</a></li>
                                    <li><a href="v-bottom">V-Bottom Bags</a></li>
                                    <li><a href="square-bottom">Square-Bottom Bags</a></li>

                                   
                                    
                                </ul>
                            </div>
                        </div>
                        
                        <!-- NEWSLETTER -->
                       
                    </div>
                </div>
            </div>
      
          
            <!-- FOOTER COPYRIGHT -->
            <div class="footer-bottom overlay-wraper">
                      
                <div class="container p-t30">
                    <div class="row ftr-btm">
                        <div class="wt-footer-bot-left">
                            <span class="copyrights-text">Copyright &copy; 2014-<script>document.write(new Date().getFullYear())</script> Gargi Paperkraft . All Rights Reserved. Designed By <a href="https://www.anchtechnologies.com" target="_blank">Anch Technologies.</a></span>
                        </div>
                        <div class="wt-footer-bot-right">
                            <ul class="copyrights-nav pull-right">
                                <li><a href="enquiry">Support 24X7</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>